import React from 'react'

const AppFooter = () => {
  return (
    <footer>
      <p>copyright &#169; 2024</p>
    </footer>
  )
}

export default AppFooter