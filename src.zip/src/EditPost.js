import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'

const EditPost = ({posts,editTitle,editBody,setEditTitle,setEditBody,handleEdit}) => {
    const {id} = useParams();
    const post = posts.find(post => (post.id).toString() === id);

    useEffect(() => {
        if(post){
            setEditTitle(post.title)
            setEditBody(post.body)
        }
    },[post,setEditTitle,setEditBody])
  return (
    <main className='newPost'>
        {
            editTitle &&

            <>
                <h2>Edit post</h2>


                <form className='newPostForm' onSubmit={(e) => e.preventDefault()}>
                    <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Title</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" required
                           value = {editTitle}
                           onChange={(e) => setEditTitle(e.target.value)} />
                    </div>
                    <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Post</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" required
                             value={editBody}
                             onChange={(e) => setEditBody(e.target.value)}></textarea>
                    </div>
                    <button type="button" class="btn btn-primary" onClick={() => handleEdit(id)}>Submit</button>
                    
            </form>

                {/*<form className='editForm' onSubmit={(e) => e.preventDefault()}>
                    <label htmlFor='postTitle'>Title:</label>
                    <input id=" postTitle" 
                           type="text"
                           required
                           value = {editTitle}
                           onChange={(e) => setEditTitle(e.target.value)}
                    />

                    <label htmlFor='postBody'>Post:</label>
                    <textarea id="postBody" 
                              required
                              value={editBody}
                              onChange={(e) => setEditBody(e.target.value)}
                    />

                    <button type='submit' onClick={() => handleEdit(id)}>Submit</button>

                </form>*/}
            </>
        } 

        {
            !editTitle &&

            <>
                <p>sorry , post not found </p>
                <p>please go to home page</p>
                <p>try again...</p>
            </>
        }

    </main>
  )
}

export default EditPost