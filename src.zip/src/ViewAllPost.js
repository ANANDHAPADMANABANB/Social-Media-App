import React from 'react'
import AppFeed from "./AppFeed"

const ViewAllPost = ({posts,search,setSearch}) => {
  return (
    <main className='allPost'>
      <section  id='search'> 
            <form className="d-flex" role="search" id='searchForm'>
              <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" id='search' value={search}
                      onChange={(e) => setSearch(e.target.value)}/>
              <button className="btn btn-outline-success" type="submit" id='searchBtn'>Search</button>
            </form>
        </section>
            {posts.length ? (<AppFeed post={posts}/>) : (<p>No post to display</p>)}
    </main>
  )
}

export default ViewAllPost