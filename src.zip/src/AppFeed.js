import React from 'react'
import AppPost from './AppPost'

const AppFeed = ({post}) => {
  return (
    <>
        {post.map((posts) =>( <AppPost key={posts.id} post={posts} />) )}
    </>
  )
}

export default AppFeed