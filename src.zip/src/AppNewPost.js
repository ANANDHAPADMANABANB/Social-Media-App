import React from 'react'

const AppNewPost = ({handleSubmit,postTitle,setPostTitle,postBody,setPostBody,}) => {
  return (
    <main className='AddNewPost'>
      <section className='newPost'>
        <h3>New Post</h3>
        

          <form className='newPostForm' onSubmit={(e) => e.preventDefault()}>
                <div className="mb-3">
                  <label htmlFor="exampleFormControlInput1" className="form-label">Title</label>
                <input type="text" className="form-control" id="exampleFormControlInput1" placeholder='title'
                        value={postTitle}
                        onChange={(e) => setPostTitle(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleFormControlTextarea1" className="form-label">Content</label>
                  <textarea className="form-control" id="exampleFormControlTextarea1" rows="5" required
                        value={postBody}
                        onChange={(e) => setPostBody(e.target.value)} 
                  />
                  
                </div>
                <button type="button" className="btn btn-primary" onClick={() => handleSubmit()}>Submit</button>
                
          </form>
      </section>
    </main>
  )
}

export default AppNewPost