import React from 'react'
import { Link, useParams } from 'react-router-dom'

const ViewOnePost = ({posts,handleDelete}) => {

    const {id} = useParams();
    const oneItem = posts.find((post) => (post.id).toString() === id)
  return (
    <main>
        {oneItem && 


            <article className="card">
                <div className="card-body">
                    
                        <h5 className="card-title" >{oneItem.title}</h5>
                        <h6 className="card-subtitle mb-2 text-body-secondary">{oneItem.date}</h6>
                    
                        <p className="card-text">{oneItem.body}</p>
                        <button type="button" class="btn btn-primary" onClick={() => handleDelete(oneItem.id)} style={{backgroundColor:"red",marginRight:"5px"}}>Delete</button>

                        <Link to = {`/edit/${id}`}>
                            <button type="button" class="btn btn-primary" style={{padding:"6px 20px"}}>Edit</button>
                        </Link>
            
                </div>
            </article>

            /*<section>
                <h3>{oneItem.title}</h3>
                <p>{oneItem.date}</p>
                <p>{oneItem.body}</p>
                <button type="submit" onClick={() => handleDelete(oneItem.id)}>Delete</button>

                <Link to = {`/edit/${id}`}>
                 <button type="submit">Edit</button>
                </Link>
            </section>*/
        }
        {!oneItem && 
            <section>
                <h3>Sorry, Data is not found</h3>
                <p>please go to home page</p>
                
            </section>
        }
        

    </main>
  )
}

export default ViewOnePost