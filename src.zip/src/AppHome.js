import React from 'react'



const AppHome = ({posts}) => {
  return (
    <main className='home'>
        <img src='' alt='' />
        <h3>Hi, Welcome to everyone..</h3>
        <p>Feel free to post your daily works and content</p>
        <p>This website will help you to show your daily work.</p>
        <p>Lets start...</p>
  </main>


  )
}

export default AppHome