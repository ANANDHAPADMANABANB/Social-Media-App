import React from 'react'

const AppAbout = () => {
  return (
    <main className='about'>
        <h4>Hi, Im B.Anandh...</h4>
        <p>Java Full Stack Developer</p>
        <p>Certified by,</p>
        <p>NIIT Institute , Anna Nagar , Chennai</p>
    </main>
  )
}

export default AppAbout