import './App.css';
import {useEffect, useState } from 'react';
import AppHeader from './AppHeader';
import AppNav from './AppNav';
import AppHome from './AppHome';
import AppNewPost from './AppNewPost';
import {Routes ,Route, useNavigate } from 'react-router-dom';
import {format} from 'date-fns'
import AppAbout from './AppAbout';

import AppMissing from './AppMissing';
import ViewOnePost from './ViewOnePost';
import api from "./api/posts"
import EditPost from './EditPost';
import ViewAllPost from './ViewAllPost';

function App() {

  const [posts,setPosts] = useState([])
  const [search,setSearch] = useState('')
  const [searchResults,setSearchResults] = useState([]) 
  const [postTitle,setPostTitle] = useState('')
  const [postBody,setPostBody] = useState('')
  const [editTitle,setEditTitle] = useState('')
  const [editBody,setEditBody] = useState('')
  const navigate = useNavigate();



//Fetching the data here..... 
  useEffect(() => {
    const fetchPosts = async() => {
      try{
        const response = await api.get("/posts")
        setPosts(response.data);
      }
      catch(err){
        if(err.respose){
          console.log(err.response.data);
          console.log(err.response.status);
          console.log(err.response.headers);
        }
        else{
          console.log(`errors : ${err.message}`)
        }
      }
    }

    fetchPosts()
   
  },[])


 
// filtering the data here for searching.... 
  useEffect(() => {
    const filterItems = posts.filter((post) =>
      ((post.body).toLowerCase()).includes((search.toLowerCase()))
    ||
      ((post.title).toLowerCase()).includes((search.toLowerCase())))
      setSearchResults(filterItems.reverse())
  },[posts,search]) 



// Adding the new post data here...
  const handleSubmit =async (e) => {
    e.preventDefault();
    const id = posts.length ? posts[posts.length -1].id +1 : 1;
    const dateTime = format(new Date(), 'MMMM dd, yyyy pp')
    const newPost={id,title:postTitle,datetime:dateTime,body:postBody}
   
    try{
      const respone = await api.post("/posts",newPost)
    
      const allPosts=[...posts,respone.data]
      setPosts(allPosts)
      setPostTitle('')
      setPostBody('')
      navigate("/")
    }
    catch(err){
      console.log(`errors : ${err.message}`)
    }
    
  }


// Deleting the post here....
  const handleDelete =async (id) => {

    try{
      await api.delete(`/posts/${id}`)
      const deleteItem = posts.filter((post) => post.id !== id)
      setPosts(deleteItem)
      navigate("/")
    }
    catch(err){
      
        console.log(`errors : ${err.message}`)
      
    }

  }


// Updating the particular data with id here....

  const handleEdit =async (id) =>{
    const dateTime = format(new Date(), 'MMMM dd, yyyy pp')
    const updatePost={id,title:editTitle,datetime:dateTime,body:editBody}
    try{
      const response =await api.put(`/posts/${id}`,updatePost)
      setPosts(posts.map(post => post.id === id ? {...response.data} : post))
      setEditTitle('')
      setEditBody('')
      navigate("/")
    }
    catch(err){
      
      console.log(`errors : ${err.message}`)
    
    }

  }



return (
  
    <div  className="App">


      <AppHeader 
        title="DaiLy pOSt"
      />


      <AppNav 
        search={search}
        setSearch={setSearch}
      />

      <Routes>

        <Route path="/" 
          element={
                    <AppHome 
                        
                    />
                  }
        />

        <Route path="viewAllPost" 
          element={
                    <ViewAllPost  
                    posts={searchResults}
                    />
                  }
        />


        <Route path="viewAllPost/post/:id" element={
                                      <ViewOnePost 
                                        posts={posts}
                                        handleDelete={handleDelete}
                                      
                                      /> 
                                    } 
          />    

        <Route path="post">
          <Route index element={
                                  <AppNewPost 
                                    postTitle={postTitle}
                                    setPostTitle={setPostTitle}
                                    postBody={postBody}
                                    setPostBody={setPostBody}
                                    handleSubmit={handleSubmit}
                                  />
                                }
          />
          
        </Route>

        <Route path="about"
          element={
                    <AppAbout />
                  }
        />

        <Route path="/edit/:id" element={
                                          <EditPost
                                            handleEdit={handleEdit}
                                            posts={posts}
                                            editTitle={editTitle}
                                            editBody={editBody}
                                            setEditTitle={setEditTitle}
                                            setEditBody={setEditBody}
                                           />
                                        }
        />

        <Route path="*" 
          element={
            <AppMissing />
          }
        />
      </Routes>


      


    </div>
  );
}

export default App;
