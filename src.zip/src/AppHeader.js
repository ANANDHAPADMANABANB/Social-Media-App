import React from 'react'

const AppHeader = ({title}) => {
  return (
    <header>
        <h3>{title}</h3>
    </header>
  )
}

export default AppHeader