import React from 'react'
import socialImage from './assert/social_media_img1.jpg'



const AppHome = () => {
  return (
    <main className='home'>
        
        <h3>Hi, Welcome to everyone..</h3>
        <p>Feel free to post your daily works and content</p>
        <p>This website will help you to show your daily work.</p>
        <p>Lets start...</p>
  </main>


  )
}

export default AppHome