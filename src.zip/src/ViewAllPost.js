import React from 'react'
import AppFeed from "./AppFeed"

const ViewAllPost = ({posts}) => {
  return (
    <main>

            {posts.length ? (<AppFeed post={posts}/>) : (<p>No post to display</p>)}
    </main>
  )
}

export default ViewAllPost