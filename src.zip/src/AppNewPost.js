import React from 'react'

const AppNewPost = ({handleSubmit,postTitle,setPostTitle,postBody,setPostBody,}) => {
  return (
    <main className='newPost'>
        <h3>New Post</h3>
        {/*<form className='newPostForm' onSubmit={handleSubmit}>
            <label htmlFor='postTitle'>Title</label>
            <input 
                id='postTitle' 
                type='text'
                placeholder='title'
                value={postTitle}
                onChange={(e) => setPostTitle(e.target.value)}
            />
            <label htmlFor='postBody'>Content</label>
            <textarea 
                id='postBody'
                required
                value={postBody}
                onChange={(e) => setPostBody(e.target.value)}
            />
            <button id="newPostSubmitbtn" type='submit'>Submit</button>
        </form>*/}

  <form className='newPostForm' onSubmit={handleSubmit}>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Title</label>
         <input type="text" class="form-control" id="exampleFormControlInput1" placeholder='title'
                value={postTitle}
                onChange={(e) => setPostTitle(e.target.value)} />
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Content</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" required
                value={postBody}
                onChange={(e) => setPostBody(e.target.value)}></textarea>
        </div>
        <button type="button" class="btn btn-primary">Submit</button>
        
  </form>
    </main>
  )
}

export default AppNewPost