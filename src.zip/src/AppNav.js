import React from 'react'
import {Link} from 'react-router-dom'
import { FaDesktop } from "react-icons/fa";
import { IoPhonePortraitSharp } from "react-icons/io5";
import { FaTabletScreenButton } from "react-icons/fa6";

const AppNav = ({width}) => {
  return (
       <nav className="navbar navbar-expand-lg bg-body-tertiary">
          <div className="container-fluid">
            
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarScroll">
              <ul className="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" >
                
                <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/" id='#nav'>Home</Link>
                </li>

                <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="viewAllPost">view post</Link>
                </li>

                <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="post">Add Post</Link>
                </li>

                <li className="nav-item dropdown">
                    <Link className="nav-link active" aria-current="page" to="about">About</Link>
                </li>

              </ul>
            </div>

            <div>
                {
                  width > 768 ? <IoPhonePortraitSharp /> : width < 992 ? <FaTabletScreenButton /> : <FaDesktop />
                }
            </div>
          </div>
       </nav>


    /* <nav>
        <form >
            <label htmlFor='search'>
                Search
            </label>
            <input 
                id='search'
                type='text'
                placeholder='search your post'
                value={search}
                onChange={(e) => setSearch(e.target.value)}
            />
        </form>
        <ul>
            <li>
                <Link to="/">Home</Link>
            </li>
            <li>
                <Link to="post">Post</Link>
            </li>
            <li>
                <Link to="about">About</Link>
            </li>
        </ul>
    </nav> */
  )
}

export default AppNav