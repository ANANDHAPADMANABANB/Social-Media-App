import React from 'react'
import {Link} from 'react-router-dom' 
const AppPost = ({post}) => {
  return (


    <article className="card">
      <div className="card-body">
      <Link to={`post/${post.id}`} id="postTitle">
        <h5 className="card-title" >{post.title}</h5>
        <h6 className="card-subtitle mb-2 text-body-secondary">{post.datetime}</h6>
        </Link>
        <p className="card-text">{(post.body).length <= 25 ? post.body : `${(post.body).slice(0,25)}...` }</p>
        
      </div>
    </article>
    
    /*<article className='post'>
      <Link to={`post/${post.id}`}>
        <h2>{post.title}</h2>
        <p>{post.datetime}</p>
        <p>{(post.body).length <= 25 ? post.body : `${(post.body).slice(0,25)}...` }</p>
      </Link>
    </article>*/
  )
}

export default AppPost